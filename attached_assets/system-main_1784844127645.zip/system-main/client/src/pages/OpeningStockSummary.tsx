import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft, Package, ChevronRight } from "lucide-react";
import { useCompany } from "@/contexts/CompanyContext";

interface StockGroupSummary {
  id: number;
  code: string;
  name: string;
  opening: {
    quantity: number;
    rate: number;
    value: number;
  };
  closing: {
    quantity: number;
    rate: number;
    value: number;
  };
  itemCount: number;
}

interface OpeningStockData {
  stockGroups: StockGroupSummary[];
  grandTotal: {
    opening: { quantity: number; value: number };
    closing: { quantity: number; value: number };
  };
}

function formatNumber(value: number, decimals: number = 2): string {
  return value.toLocaleString("en-US", {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
}

function formatQty(value: number): string {
  if (value === 0) return "";
  return formatNumber(value);
}

function formatValue(value: number): string {
  if (value === 0) return "";
  return formatNumber(value);
}

export default function OpeningStockSummary() {
  const [, navigate] = useLocation();
  const { selectedCompany } = useCompany();

  const { data, isLoading } = useQuery<OpeningStockData>({
    queryKey: ["/api/reports/opening-stock-summary", selectedCompany?.id],
    enabled: !!selectedCompany?.id,
  });

  const handleGroupClick = (groupId: number, groupName: string) => {
    navigate(`/opening-stock/${groupId}?name=${encodeURIComponent(groupName)}`);
  };

  // Calculate grand total rates
  const openingRate = data?.grandTotal?.opening?.quantity && data.grandTotal.opening.quantity > 0
    ? data.grandTotal.opening.value / data.grandTotal.opening.quantity
    : 0;
  const closingRate = data?.grandTotal?.closing?.quantity && data.grandTotal.closing.quantity > 0
    ? data.grandTotal.closing.value / data.grandTotal.closing.quantity
    : 0;

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center gap-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => navigate("/analytics")}
          data-testid="button-back"
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Package className="h-6 w-6" />
            Opening Stock Summary
          </h1>
          <p className="text-muted-foreground text-sm">
            {selectedCompany?.name}
          </p>
        </div>
      </div>

      <Card className="overflow-hidden">
        {/* Header */}
        <div className="bg-primary text-primary-foreground">
          <div className="grid grid-cols-7 p-3 font-semibold text-sm">
            <div className="col-span-1">Particulars</div>
            <div className="col-span-3 text-center border-l border-primary-foreground/30">
              Opening Balance
            </div>
            <div className="col-span-3 text-center border-l border-primary-foreground/30">
              Closing Balance
            </div>
          </div>
          <div className="grid grid-cols-7 px-3 pb-2 text-xs">
            <div></div>
            <div className="text-right">Quantity</div>
            <div className="text-right">Rate</div>
            <div className="text-right">Value</div>
            <div className="text-right border-l border-primary-foreground/30 pl-2">Quantity</div>
            <div className="text-right">Rate</div>
            <div className="text-right">Value</div>
          </div>
        </div>

        {/* Body */}
        <div className="divide-y">
          {isLoading ? (
            <div className="p-4 space-y-3">
              {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
                <Skeleton key={i} className="h-10 w-full" />
              ))}
            </div>
          ) : data?.stockGroups && data.stockGroups.length > 0 ? (
            <>
              {data.stockGroups.map((group) => (
                <div
                  key={group.id}
                  className="grid grid-cols-7 p-3 cursor-pointer hover-elevate"
                  onClick={() => handleGroupClick(group.id, group.name)}
                  data-testid={`row-stock-group-${group.id}`}
                >
                  <div className="font-medium flex items-center gap-1">
                    <ChevronRight className="h-4 w-4 text-muted-foreground" />
                    {group.name}
                  </div>
                  {/* Opening Balance */}
                  <div className="text-right font-mono text-sm">
                    {formatQty(group.opening.quantity)}
                  </div>
                  <div className="text-right font-mono text-sm">
                    {formatValue(group.opening.rate)}
                  </div>
                  <div className="text-right font-mono text-sm">
                    {formatValue(group.opening.value)}
                  </div>
                  {/* Closing Balance */}
                  <div className="text-right font-mono text-sm border-l pl-2">
                    {formatQty(group.closing.quantity)}
                  </div>
                  <div className="text-right font-mono text-sm">
                    {formatValue(group.closing.rate)}
                  </div>
                  <div className="text-right font-mono text-sm">
                    {formatValue(group.closing.value)}
                  </div>
                </div>
              ))}
            </>
          ) : (
            <div className="p-8 text-center text-muted-foreground">
              No opening stock data available.
            </div>
          )}
        </div>

        {/* Grand Total */}
        {data?.grandTotal && (
          <div className="bg-muted/50 border-t-2 border-primary">
            <div className="grid grid-cols-7 p-3 font-bold">
              <div>Grand Total</div>
              {/* Opening Total */}
              <div className="text-right font-mono">
                {formatNumber(data.grandTotal.opening.quantity)}
              </div>
              <div className="text-right font-mono">
                {formatNumber(openingRate)}
              </div>
              <div className="text-right font-mono">
                {formatNumber(data.grandTotal.opening.value)}
              </div>
              {/* Closing Total */}
              <div className="text-right font-mono border-l pl-2">
                {formatNumber(data.grandTotal.closing.quantity)}
              </div>
              <div className="text-right font-mono">
                {formatNumber(closingRate)}
              </div>
              <div className="text-right font-mono">
                {formatNumber(data.grandTotal.closing.value)}
              </div>
            </div>
          </div>
        )}
      </Card>
    </div>
  );
}
