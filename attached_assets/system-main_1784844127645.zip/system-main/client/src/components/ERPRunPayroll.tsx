import { useState, useMemo } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import {
  Users, Search, ChevronDown, ChevronRight, DollarSign, Loader2,
  PlayCircle, Banknote, FileSpreadsheet, Printer,
  CheckCircle2, History, ArrowLeft, Trash2, ClipboardList,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useCurrencyContext } from "@/contexts/CurrencyContext";

const AVATAR_COLORS = [
  "bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300",
  "bg-purple-100 text-purple-700 dark:bg-purple-900/40 dark:text-purple-300",
  "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300",
  "bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300",
  "bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300",
  "bg-cyan-100 text-cyan-700 dark:bg-cyan-900/40 dark:text-cyan-300",
  "bg-indigo-100 text-indigo-700 dark:bg-indigo-900/40 dark:text-indigo-300",
  "bg-teal-100 text-teal-700 dark:bg-teal-900/40 dark:text-teal-300",
];
function getAvatarColor(name: string) {
  let h = 0;
  for (const c of name) h = c.charCodeAt(0) + ((h << 5) - h);
  return AVATAR_COLORS[Math.abs(h) % AVATAR_COLORS.length];
}
function getInitials(name: string) {
  return name.split(" ").filter(Boolean).slice(0, 2).map((n) => n[0]).join("").toUpperCase();
}
function fmt(val: string | number | null | undefined) {
  const n = parseFloat(String(val || 0));
  return isNaN(n) ? "0.00" : n.toFixed(2);
}

interface Employee {
  id: number;
  code: string;
  firstName: string;
  lastName: string;
  department: string | null;
  employeeType: string;
  monthlySalary: string | null;
  active: boolean;
}
interface WorkerGroup {
  id: number;
  name: string;
  members: { id: number }[];
}
interface LedgerAccount {
  id: number;
  name: string;
  code: string;
  accountType: string;
}
interface SalaryAdvance {
  id: number;
  employeeId: number;
  amount: string;
  remainingBalance: string;
  fullyPaid: boolean;
}
interface PreviewItem {
  employeeId: number;
  employeeName: string;
  groupName: string;
  baseSalary: number;
  deduction: number;
  netPay: number;
}
interface PayrollRun {
  id: number;
  status: string;
  date: string;
  notes: string | null;
  paymentAccountId: number | null;
  paidAt: string | null;
  createdAt: string;
  itemCount: number;
  totalNet: string;
  totalBase: string;
  items: PayrollRunItem[];
}
interface PayrollRunItem {
  id: number;
  runId: number;
  employeeId: number;
  employeeName: string;
  groupName: string | null;
  baseSalary: string;
  deduction: string;
  netPay: string;
}

export default function ERPRunPayroll() {
  const { toast } = useToast();
  const { formatAmount } = useCurrencyContext();

  const [activeTab, setActiveTab] = useState<"run" | "history">("run");

  // ── Step 1: worker selection ──────────────────────────────────────────────
  const [searchQuery, setSearchQuery] = useState("");
  const [expandedGroups, setExpandedGroups] = useState<Record<number | string, boolean>>({});
  const [selectedWorkers, setSelectedWorkers] = useState<Set<number>>(new Set());

  // ── Step 2: preview / draft ───────────────────────────────────────────────
  const [step, setStep] = useState<1 | 2>(1);
  const [previewItems, setPreviewItems] = useState<PreviewItem[]>([]);
  const [previewDate, setPreviewDate] = useState(new Date().toISOString().split("T")[0]);
  const [previewNotes, setPreviewNotes] = useState("");

  // ── History: pay dialog ───────────────────────────────────────────────────
  const [payDialogRun, setPayDialogRun] = useState<PayrollRun | null>(null);
  const [payAccountId, setPayAccountId] = useState("");
  const [deleteRunId, setDeleteRunId] = useState<number | null>(null);

  // ── Queries ───────────────────────────────────────────────────────────────
  const { data: allEmployees, isLoading: empLoading } = useQuery<Employee[]>({ queryKey: ["/api/employees"] });

  const { data: workerGroupsRaw = [], isLoading: groupsLoading } = useQuery<WorkerGroup[]>({
    queryKey: ["/api/worker-groups/with-members"],
    queryFn: async () => {
      const res = await fetch("/api/worker-groups/with-members", { credentials: "include" });
      if (!res.ok) return [];
      return res.json();
    },
  });

  const { data: ledgerAccounts = [] } = useQuery<LedgerAccount[]>({
    queryKey: ["/api/ledger-accounts"],
    queryFn: async () => {
      const res = await fetch("/api/ledger-accounts", { credentials: "include" });
      if (!res.ok) return [];
      return res.json();
    },
  });

  const { data: salaryAdvances = [] } = useQuery<SalaryAdvance[]>({
    queryKey: ["/api/salary-advances"],
    queryFn: async () => {
      const res = await fetch("/api/salary-advances", { credentials: "include" });
      if (!res.ok) return [];
      return res.json();
    },
  });

  const { data: payrollRuns = [], isLoading: runsLoading } = useQuery<PayrollRun[]>({
    queryKey: ["/api/payroll/runs"],
    queryFn: async () => {
      const res = await fetch("/api/payroll/runs", { credentials: "include" });
      if (!res.ok) return [];
      return res.json();
    },
  });

  const cashAccounts = useMemo(() => ledgerAccounts.filter((a) => a.accountType === "Cash"), [ledgerAccounts]);
  const workers = useMemo(() => (allEmployees || []).filter((e) => e.employeeType === "Worker" && e.active), [allEmployees]);
  const workerGroups = useMemo(
    () => workerGroupsRaw.filter((g: any) => { const t = g.groupType || g.group_type; return !t || t === "Worker"; }),
    [workerGroupsRaw],
  );

  const advanceBalanceByEmployee = useMemo(() => {
    const map: Record<number, number> = {};
    for (const adv of salaryAdvances) {
      if (!adv.fullyPaid) {
        const bal = parseFloat(adv.remainingBalance || "0");
        if (bal > 0) map[adv.employeeId] = (map[adv.employeeId] || 0) + bal;
      }
    }
    return map;
  }, [salaryAdvances]);

  const workerMemberships = useMemo(() => {
    const map: Record<number, number[]> = {};
    for (const g of workerGroups) for (const m of g.members || []) {
      if (!map[m.id]) map[m.id] = [];
      map[m.id].push(g.id);
    }
    return map;
  }, [workerGroups]);

  const ungroupedWorkers = useMemo(() => workers.filter((w) => !(workerMemberships[w.id]?.length)), [workers, workerMemberships]);

  const filtered = useMemo(() => {
    if (!searchQuery.trim()) return new Set(workers.map((w) => w.id));
    const q = searchQuery.toLowerCase();
    return new Set(workers.filter((w) =>
      `${w.firstName} ${w.lastName}`.toLowerCase().includes(q) || w.code?.toLowerCase().includes(q) || (w.department || "").toLowerCase().includes(q)
    ).map((w) => w.id));
  }, [workers, searchQuery]);

  const workerById = useMemo(() => {
    const map: Record<number, Employee> = {};
    for (const w of workers) map[w.id] = w;
    return map;
  }, [workers]);

  // ── Helpers ───────────────────────────────────────────────────────────────
  function toggleGroup(key: number | string) { setExpandedGroups((p) => ({ ...p, [key]: !(p[key] ?? true) })); }
  function toggleWorker(id: number) {
    setSelectedWorkers((p) => {
      const n = new Set(p);
      if (n.has(id)) n.delete(id);
      else n.add(id);
      return n;
    });
  }
  function toggleGroupSelection(memberIds: number[]) {
    const visible = memberIds.filter((id) => filtered.has(id));
    const allSel = visible.every((id) => selectedWorkers.has(id));
    setSelectedWorkers((p) => {
      const n = new Set(p);
      if (allSel) visible.forEach((id) => n.delete(id));
      else visible.forEach((id) => n.add(id));
      return n;
    });
  }

  function enterPreview() {
    const items: PreviewItem[] = [];
    function addGroup(label: string, memberIds: number[]) {
      for (const id of memberIds) {
        if (!selectedWorkers.has(id) || !workerById[id]) continue;
        const w = workerById[id];
        const salary = parseFloat(w.monthlySalary || "0");
        const deduction = Math.min(advanceBalanceByEmployee[id] || 0, salary);
        items.push({
          employeeId: id,
          employeeName: `${w.firstName} ${w.lastName}`.trim(),
          groupName: label,
          baseSalary: salary,
          deduction,
          netPay: Math.max(0, salary - deduction),
        });
      }
    }
    for (const g of workerGroups) addGroup(g.name, (g.members || []).map((m) => m.id));
    if (ungroupedWorkers.length > 0) addGroup("Ungrouped", ungroupedWorkers.map((w) => w.id));
    setPreviewItems(items);
    setPreviewDate(new Date().toISOString().split("T")[0]);
    setPreviewNotes("");
    setStep(2);
  }

  function updateDeduction(idx: number, val: string) {
    setPreviewItems((prev) => prev.map((it, i) => {
      if (i !== idx) return it;
      const ded = Math.max(0, parseFloat(val) || 0);
      return { ...it, deduction: ded, netPay: Math.max(0, it.baseSalary - ded) };
    }));
  }

  // ── Mutations ─────────────────────────────────────────────────────────────
  const saveDraftMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/payroll/runs", {
        date: previewDate,
        notes: previewNotes || undefined,
        items: previewItems.map((it) => ({
          employeeId: it.employeeId,
          employeeName: it.employeeName,
          groupName: it.groupName,
          baseSalary: it.baseSalary.toFixed(2),
          deduction: it.deduction.toFixed(2),
          netPay: it.netPay.toFixed(2),
        })),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Failed to save draft");
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/payroll/runs"] });
      toast({ title: "Draft saved", description: "Payroll saved as draft. Go to History to pay it." });
      setStep(1);
      setSelectedWorkers(new Set());
      setPreviewItems([]);
      setActiveTab("history");
    },
    onError: (e: Error) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const payRunMutation = useMutation({
    mutationFn: async ({ runId, accountId }: { runId: number; accountId: string }) => {
      const res = await apiRequest("PATCH", `/api/payroll/runs/${runId}`, {
        action: "pay",
        paymentAccountId: parseInt(accountId),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Failed to pay");
      return data;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/payroll/runs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/ledger-accounts"] });
      toast({ title: "Payroll paid", description: "Ledger entries created successfully." });
      setPayDialogRun(null);
      setPayAccountId("");
      // Print immediately after paying
      if (payDialogRun) {
        const run = { ...payDialogRun, status: "PAID" };
        setTimeout(() => printRun(run), 300);
      }
    },
    onError: (e: Error) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const deleteRunMutation = useMutation({
    mutationFn: async (runId: number) => {
      const res = await apiRequest("DELETE", `/api/payroll/runs/${runId}`, undefined);
      if (!res.ok) { const d = await res.json(); throw new Error(d.message || "Failed to delete"); }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/payroll/runs"] });
      toast({ title: "Draft deleted" });
      setDeleteRunId(null);
    },
    onError: (e: Error) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  // ── Print ─────────────────────────────────────────────────────────────────
  // Escape every user-controlled string before interpolating into the print
  // window's HTML. Without this, an attacker who can store HTML in fields like
  // employeeName / groupName / notes can execute scripts whenever a payroll
  // report is printed (stored XSS).
  function escHtml(v: unknown): string {
    return String(v ?? "").replace(/[&<>"']/g, (c) => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;",
    }[c] as string));
  }

  function printRun(run: PayrollRun) {
    const items = run.items || [];
    const dateStr = run.date;
    const notes = run.notes || "";
    const totalBase = items.reduce((s, i) => s + parseFloat(i.baseSalary), 0);
    const totalDed = items.reduce((s, i) => s + parseFloat(i.deduction), 0);
    const totalNet = items.reduce((s, i) => s + parseFloat(i.netPay), 0);

    const groupMap: Record<string, typeof items> = {};
    for (const it of items) {
      const g = it.groupName || "Ungrouped";
      if (!groupMap[g]) groupMap[g] = [];
      groupMap[g].push(it);
    }

    const bodyRows = Object.entries(groupMap).map(([grp, members]) => {
      const memberRows = members.map((m, i) => `
        <tr style="background:${i % 2 === 0 ? "#fff" : "#f4f8fc"}">
          <td style="padding:5px 8px;border-bottom:1px solid #e4e8ed">${escHtml(m.employeeName)}</td>
          <td style="padding:5px 8px;border-bottom:1px solid #e4e8ed;text-align:right">${parseFloat(m.baseSalary).toFixed(2)}</td>
          <td style="padding:5px 8px;border-bottom:1px solid #e4e8ed;text-align:right;color:${parseFloat(m.deduction) > 0 ? "#b45309" : "#999"}">${parseFloat(m.deduction) > 0 ? `-${parseFloat(m.deduction).toFixed(2)}` : "—"}</td>
          <td style="padding:5px 8px;border-bottom:1px solid #e4e8ed;text-align:right;font-weight:600">${parseFloat(m.netPay).toFixed(2)}</td>
          <td style="padding:5px 8px;border-bottom:1px solid #e4e8ed;text-align:center;color:#999">___________</td>
        </tr>`).join("");
      const gBase = members.reduce((s, m) => s + parseFloat(m.baseSalary), 0);
      const gDed = members.reduce((s, m) => s + parseFloat(m.deduction), 0);
      const gNet = members.reduce((s, m) => s + parseFloat(m.netPay), 0);
      return `
        <tr><td colspan="5" style="padding:6px 8px;background:#1e3a5f;color:#fff;font-weight:700;font-size:11px">${escHtml(grp)}</td></tr>
        ${memberRows}
        <tr style="background:#d6e4f0">
          <td style="padding:5px 8px;font-weight:700;font-size:11px">${escHtml(grp)} — Total</td>
          <td style="padding:5px 8px;text-align:right;font-weight:700">${gBase.toFixed(2)}</td>
          <td style="padding:5px 8px;text-align:right;font-weight:700">${gDed > 0 ? `-${gDed.toFixed(2)}` : "—"}</td>
          <td style="padding:5px 8px;text-align:right;font-weight:700">${gNet.toFixed(2)}</td>
          <td style="padding:5px 8px"></td>
        </tr>`;
    }).join("");

    const statusLine = run.status === "PAID"
      ? `<div style="display:inline-block;background:#16a34a;color:#fff;font-weight:700;padding:3px 10px;border-radius:4px;font-size:11px;margin-bottom:8px">PAID</div>`
      : `<div style="display:inline-block;background:#ca8a04;color:#fff;font-weight:700;padding:3px 10px;border-radius:4px;font-size:11px;margin-bottom:8px">DRAFT</div>`;

    const html = `<!DOCTYPE html><html><head><title>Payroll Report — ${escHtml(dateStr)}</title>
      <style>
        body{font-family:Arial,sans-serif;font-size:12px;margin:24px;color:#222}
        h1{color:#1e3a5f;margin:0 0 2px}
        table{width:100%;border-collapse:collapse;margin-top:12px}
        th{background:#1e3a5f;color:#fff;padding:6px 8px;text-align:left;font-size:11px}
        th:nth-child(n+2){text-align:right}
        th:last-child{text-align:center}
        @media print{button{display:none}.no-print{display:none}}
      </style>
      </head><body>
      <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:12px">
        <div>
          <h1>Payroll Report</h1>
          ${statusLine}
          ${notes ? `<p style="color:#666;margin:2px 0 0;font-size:11px">${escHtml(notes)}</p>` : ""}
        </div>
        <div style="text-align:right;color:#555;font-size:11px">
          <div><strong>Date:</strong> ${escHtml(dateStr)}</div>
          <div><strong>Workers:</strong> ${items.length}</div>
        </div>
      </div>
      <table>
        <thead><tr>
          <th>Worker</th>
          <th style="text-align:right">Base Salary</th>
          <th style="text-align:right">Deduction</th>
          <th style="text-align:right">Net Pay</th>
          <th style="text-align:center">Signature</th>
        </tr></thead>
        <tbody>${bodyRows}
          <tr style="background:#1e3a5f;color:#fff">
            <td style="padding:6px 8px;font-weight:700">GRAND TOTAL</td>
            <td style="padding:6px 8px;text-align:right;font-weight:700">${totalBase.toFixed(2)}</td>
            <td style="padding:6px 8px;text-align:right;font-weight:700">${totalDed > 0 ? `-${totalDed.toFixed(2)}` : "—"}</td>
            <td style="padding:6px 8px;text-align:right;font-weight:700">${totalNet.toFixed(2)}</td>
            <td style="padding:6px 8px"></td>
          </tr>
        </tbody>
      </table>
      <div class="no-print" style="margin-top:16px;text-align:right">
        <button onclick="window.print()" style="padding:6px 16px;background:#1e3a5f;color:#fff;border:none;border-radius:4px;cursor:pointer;font-size:12px">Print / Save PDF</button>
      </div>
      <script>window.onload=()=>window.print();</script>
    </body></html>`;
    const w = window.open("", "_blank");
    if (w) { w.document.write(html); w.document.close(); }
  }

  // ── Excel export for a run (exceljs-backed; was xlsx-js-style) ────────────
  async function exportRunExcel(run: PayrollRun) {
    const ExcelJS = (await import("exceljs")).default;
    const items = run.items || [];

    const wb = new ExcelJS.Workbook();
    const ws = wb.addWorksheet("Payroll");

    ws.columns = [
      { width: 18 },
      { width: 28 },
      { width: 16 },
      { width: 16 },
      { width: 16 },
    ];

    // Title row (merged across cols A:D, date in E)
    const titleRow = ws.addRow(["Payroll Report", "", "", "", run.date]);
    ws.mergeCells(titleRow.number, 1, titleRow.number, 4);
    titleRow.font = { bold: true, size: 14 };
    titleRow.alignment = { vertical: "middle", horizontal: "left" };

    ws.addRow([]); // spacer

    // Header row
    const headerRow = ws.addRow(["Group", "Worker", "Base Salary", "Deduction", "Net Pay"]);
    headerRow.font = { bold: true };
    headerRow.alignment = { horizontal: "center" };

    // Data rows
    for (const it of items) {
      ws.addRow([
        it.groupName || "Ungrouped",
        it.employeeName,
        parseFloat(it.baseSalary),
        parseFloat(it.deduction),
        parseFloat(it.netPay),
      ]);
    }

    const totalBase = items.reduce((s, i) => s + parseFloat(i.baseSalary), 0);
    const totalDed = items.reduce((s, i) => s + parseFloat(i.deduction), 0);
    const totalNet = items.reduce((s, i) => s + parseFloat(i.netPay), 0);
    const totalRow = ws.addRow(["", "GRAND TOTAL", totalBase, totalDed, totalNet]);
    totalRow.font = { bold: true };

    // Number format for currency columns (C, D, E) on data + total rows
    for (let r = 4; r <= totalRow.number; r++) {
      for (const col of [3, 4, 5]) {
        ws.getCell(r, col).numFmt = "#,##0.00";
      }
    }

    // Trigger download
    const buf = await wb.xlsx.writeBuffer();
    const blob = new Blob([buf], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `payroll-run-${run.id}-${run.date}.xlsx`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  const isLoading = empLoading || groupsLoading;
  const totalSelectedBase = useMemo(() => Array.from(selectedWorkers).reduce((s, id) => s + parseFloat(workerById[id]?.monthlySalary || "0"), 0), [selectedWorkers, workerById]);
  const previewTotalNet = useMemo(() => previewItems.reduce((s, it) => s + it.netPay, 0), [previewItems]);
  const previewTotalBase = useMemo(() => previewItems.reduce((s, it) => s + it.baseSalary, 0), [previewItems]);

  // ── Worker card ────────────────────────────────────────────────────────────
  function renderWorkerCard(worker: Employee) {
    if (!filtered.has(worker.id)) return null;
    const fullName = `${worker.firstName} ${worker.lastName}`.trim();
    const isSelected = selectedWorkers.has(worker.id);
    const advanceBalance = advanceBalanceByEmployee[worker.id] || 0;
    const salary = parseFloat(worker.monthlySalary || "0");
    return (
      <div
        key={worker.id}
        className={`cursor-pointer rounded-md transition-all ${isSelected ? "ring-2 ring-primary" : ""}`}
        onClick={() => toggleWorker(worker.id)}
        data-testid={`card-worker-${worker.id}`}
      >
        <Card className={`hover-elevate h-full ${isSelected ? "bg-primary/5" : ""}`}>
          <CardContent className="p-4 flex flex-col h-full">
            <div className="flex items-start justify-between mb-3">
              <Avatar className={`h-12 w-12 text-sm font-semibold ${getAvatarColor(fullName)}`}>
                <AvatarFallback className={getAvatarColor(fullName)}>{getInitials(fullName)}</AvatarFallback>
              </Avatar>
              <Badge variant={worker.active ? "default" : "secondary"} className="text-xs no-default-active-elevate">
                {worker.active ? "Active" : "Inactive"}
              </Badge>
            </div>
            <div className="flex-1">
              <p className="font-semibold text-sm leading-tight">{fullName}</p>
              {worker.department && <p className="text-xs text-muted-foreground mt-0.5">{worker.department}</p>}
            </div>
            <div className="mt-3 pt-3 border-t space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground font-mono">{worker.code || "—"}</span>
                <span className="text-xs font-medium">{formatAmount(salary)}</span>
              </div>
              {advanceBalance > 0 && (
                <div className="flex items-center justify-between">
                  <span className="text-xs text-amber-600 dark:text-amber-400 flex items-center gap-1">
                    <Banknote className="h-3 w-3" />Advance
                  </span>
                  <span className="text-xs text-amber-600 dark:text-amber-400 font-medium">-{formatAmount(advanceBalance)}</span>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  function renderGroup(label: string, memberIds: number[], groupKey: number | string) {
    const visible = memberIds.filter((id) => filtered.has(id) && workerById[id]);
    if (visible.length === 0) return null;
    const isExpanded = expandedGroups[groupKey] ?? true;
    const allSel = visible.every((id) => selectedWorkers.has(id));
    const someSel = visible.some((id) => selectedWorkers.has(id));
    return (
      <div key={groupKey} className="space-y-3">
        <div className="flex items-center gap-2">
          <button
            onClick={() => toggleGroup(groupKey)}
            className="flex items-center gap-2 text-sm font-semibold text-foreground hover:text-primary transition-colors"
            data-testid={`group-toggle-${groupKey}`}
          >
            {isExpanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
            {label}
            <span className="text-xs font-normal text-muted-foreground">({visible.length})</span>
          </button>
          <Button variant="ghost" size="sm" className="text-xs h-6 px-2" onClick={() => toggleGroupSelection(memberIds)} data-testid={`group-select-all-${groupKey}`}>
            {allSel ? "Deselect all" : someSel ? "Select rest" : "Select all"}
          </Button>
        </div>
        {isExpanded && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {visible.map((id) => renderWorkerCard(workerById[id]))}
          </div>
        )}
      </div>
    );
  }

  const hasResults = workers.some((w) => filtered.has(w.id));

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-10 w-full" />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {Array.from({ length: 8 }).map((_, i) => <Skeleton key={i} className="h-36 rounded-md" />)}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <Tabs value={activeTab} onValueChange={(v) => { setActiveTab(v as any); setStep(1); }}>
        <TabsList>
          <TabsTrigger value="run" data-testid="tab-run-payroll">
            <PlayCircle className="h-4 w-4 mr-2" />
            Run Payroll
          </TabsTrigger>
          <TabsTrigger value="history" data-testid="tab-payroll-history">
            <History className="h-4 w-4 mr-2" />
            Payroll History
            {payrollRuns.filter((r) => r.status === "DRAFT").length > 0 && (
              <Badge variant="outline" className="ml-2 text-xs no-default-active-elevate">
                {payrollRuns.filter((r) => r.status === "DRAFT").length} draft
              </Badge>
            )}
          </TabsTrigger>
        </TabsList>

        {/* ── TAB 1: Run Payroll ─────────────────────────────────────────── */}
        <TabsContent value="run" className="mt-4">
          {step === 1 ? (
            <>
              {/* Toolbar */}
              <div className="flex flex-wrap items-center gap-3 mb-4">
                <div className="relative flex-1 min-w-52">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search by name, code, department..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-9"
                    data-testid="input-search-workers"
                  />
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                  {selectedWorkers.size > 0 && (
                    <span className="text-sm text-muted-foreground">
                      {selectedWorkers.size} selected — {formatAmount(totalSelectedBase)}
                    </span>
                  )}
                  <Button
                    onClick={enterPreview}
                    disabled={selectedWorkers.size === 0}
                    data-testid="button-preview-payroll"
                  >
                    <ClipboardList className="h-4 w-4 mr-2" />
                    Preview Payroll ({selectedWorkers.size})
                  </Button>
                </div>
              </div>

              {!hasResults ? (
                <div className="text-center py-20 text-muted-foreground">
                  <Users className="mx-auto h-10 w-10 mb-3 opacity-40" />
                  <p className="font-medium">{searchQuery ? "No workers match your search" : "No active workers found"}</p>
                </div>
              ) : (
                <div className="space-y-6">
                  {workerGroups.map((group) => renderGroup(group.name, (group.members || []).map((m) => m.id), group.id))}
                  {ungroupedWorkers.filter((w) => filtered.has(w.id)).length > 0 &&
                    renderGroup("Ungrouped", ungroupedWorkers.map((w) => w.id), "ungrouped")}
                </div>
              )}
            </>
          ) : (
            /* ── Step 2: Preview & Save as Draft ───────────────────────── */
            <div className="space-y-4">
              {/* Header */}
              <div className="flex items-center justify-between gap-3 flex-wrap">
                <div className="flex items-center gap-3">
                  <Button variant="ghost" size="sm" onClick={() => setStep(1)} data-testid="button-back-to-select">
                    <ArrowLeft className="h-4 w-4 mr-1" />Back
                  </Button>
                  <h3 className="font-semibold text-sm">
                    Payroll Preview — {previewItems.length} worker{previewItems.length !== 1 ? "s" : ""}
                  </h3>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    onClick={() => saveDraftMutation.mutate()}
                    disabled={saveDraftMutation.isPending || previewTotalNet <= 0}
                    data-testid="button-save-draft"
                  >
                    {saveDraftMutation.isPending ? (
                      <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Saving...</>
                    ) : (
                      <><CheckCircle2 className="h-4 w-4 mr-2" />Save as Draft</>
                    )}
                  </Button>
                </div>
              </div>

              {/* Date + Notes */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Payroll Date</Label>
                  <Input type="date" value={previewDate} onChange={(e) => setPreviewDate(e.target.value)} data-testid="input-preview-date" />
                </div>
                <div className="space-y-2">
                  <Label>Notes (optional)</Label>
                  <Input placeholder="e.g. March 2026 payroll" value={previewNotes} onChange={(e) => setPreviewNotes(e.target.value)} data-testid="input-preview-notes" />
                </div>
              </div>

              {/* Preview table */}
              <div className="border rounded-md overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Worker</TableHead>
                      <TableHead className="text-muted-foreground text-xs font-medium">Group</TableHead>
                      <TableHead className="text-right">Base Salary</TableHead>
                      <TableHead className="text-right w-40">Advance Deduction</TableHead>
                      <TableHead className="text-right">Net Pay</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {previewItems.map((it, idx) => {
                      const advBal = advanceBalanceByEmployee[it.employeeId] || 0;
                      return (
                        <TableRow key={idx} data-testid={`row-preview-${it.employeeId}`}>
                          <TableCell className="font-medium text-sm">{it.employeeName}</TableCell>
                          <TableCell className="text-xs text-muted-foreground">{it.groupName}</TableCell>
                          <TableCell className="text-right text-sm">{formatAmount(it.baseSalary)}</TableCell>
                          <TableCell className="text-right">
                            <div className="flex flex-col items-end gap-1">
                              <Input
                                type="number"
                                min="0"
                                max={String(it.baseSalary)}
                                step="0.01"
                                placeholder="0.00"
                                className="h-8 text-sm w-28 text-right"
                                value={it.deduction === 0 ? "" : it.deduction}
                                onChange={(e) => updateDeduction(idx, e.target.value)}
                                data-testid={`input-deduction-${it.employeeId}`}
                              />
                              {advBal > 0 && (() => {
                                const remaining = advBal - it.deduction;
                                return remaining > 0.005 ? (
                                  <span className="text-xs text-amber-600 dark:text-amber-400">
                                    Remaining: {formatAmount(remaining)}
                                  </span>
                                ) : (
                                  <span className="text-xs text-green-600 dark:text-green-400">
                                    Fully deducted
                                  </span>
                                );
                              })()}
                            </div>
                          </TableCell>
                          <TableCell className="text-right font-semibold text-sm" data-testid={`text-net-${it.employeeId}`}>
                            {formatAmount(it.netPay)}
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
              <div className="flex justify-end gap-6 text-sm text-muted-foreground px-1">
                <span>Total Base: <span className="font-semibold text-foreground">{formatAmount(previewTotalBase)}</span></span>
                <span>Net Payable: <span className="font-semibold text-foreground">{formatAmount(previewTotalNet)}</span></span>
              </div>
            </div>
          )}
        </TabsContent>

        {/* ── TAB 2: Payroll History ──────────────────────────────────────── */}
        <TabsContent value="history" className="mt-4">
          {runsLoading ? (
            <div className="space-y-3">
              {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-16 rounded-md" />)}
            </div>
          ) : payrollRuns.length === 0 ? (
            <div className="text-center py-20 text-muted-foreground">
              <History className="mx-auto h-10 w-10 mb-3 opacity-40" />
              <p className="font-medium">No payroll runs yet</p>
              <p className="text-sm mt-1">Select workers and run a payroll to get started.</p>
            </div>
          ) : (
            <div className="border rounded-md overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Notes</TableHead>
                    <TableHead className="text-right">Workers</TableHead>
                    <TableHead className="text-right">Total Base</TableHead>
                    <TableHead className="text-right">Net Payable</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {payrollRuns.map((run) => (
                    <TableRow key={run.id} data-testid={`row-run-${run.id}`}>
                      <TableCell className="font-medium text-sm">{run.date}</TableCell>
                      <TableCell className="text-sm text-muted-foreground max-w-48 truncate">{run.notes || "—"}</TableCell>
                      <TableCell className="text-right text-sm">{run.itemCount}</TableCell>
                      <TableCell className="text-right text-sm">{formatAmount(parseFloat(run.totalBase))}</TableCell>
                      <TableCell className="text-right font-semibold text-sm">{formatAmount(parseFloat(run.totalNet))}</TableCell>
                      <TableCell>
                        {run.status === "PAID" ? (
                          <Badge variant="secondary" className="bg-green-50 text-green-700 dark:bg-green-900/30 dark:text-green-400 no-default-active-elevate">Paid</Badge>
                        ) : (
                          <Badge variant="outline" className="bg-yellow-50 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400 no-default-active-elevate">Draft</Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center justify-end gap-1">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => printRun(run)}
                            title="Print / PDF"
                            data-testid={`button-print-run-${run.id}`}
                          >
                            <Printer className="h-4 w-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => exportRunExcel(run)}
                            title="Export Excel"
                            data-testid={`button-excel-run-${run.id}`}
                          >
                            <FileSpreadsheet className="h-4 w-4" />
                          </Button>
                          {run.status === "DRAFT" && (
                            <>
                              <Button
                                size="sm"
                                onClick={() => { setPayDialogRun(run); setPayAccountId(""); }}
                                data-testid={`button-pay-run-${run.id}`}
                              >
                                <DollarSign className="h-3.5 w-3.5 mr-1" />
                                Pay
                              </Button>
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => setDeleteRunId(run.id)}
                                className="text-destructive"
                                title="Delete draft"
                                data-testid={`button-delete-run-${run.id}`}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* ── Pay Dialog ─────────────────────────────────────────────────────── */}
      <Dialog open={!!payDialogRun} onOpenChange={(open) => { if (!open) setPayDialogRun(null); }}>
        <DialogContent className="max-w-lg" data-testid="dialog-pay-run">
          <DialogHeader>
            <DialogTitle>Pay Payroll Draft</DialogTitle>
            <DialogDescription>
              This will create ledger entries and mark the payroll as paid. Net total:{" "}
              <strong>{payDialogRun ? formatAmount(parseFloat(payDialogRun.totalNet)) : ""}</strong>
            </DialogDescription>
          </DialogHeader>

          {payDialogRun && (
            <div className="space-y-4 py-2">
              <div className="rounded-md bg-muted/40 px-4 py-3 space-y-1">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Date</span>
                  <span className="font-medium">{payDialogRun.date}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Workers</span>
                  <span className="font-medium">{payDialogRun.itemCount}</span>
                </div>
                {payDialogRun.notes && (
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Notes</span>
                    <span className="font-medium">{payDialogRun.notes}</span>
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <Label>Payment Account (Cash)</Label>
                <Select value={payAccountId} onValueChange={setPayAccountId}>
                  <SelectTrigger data-testid="select-pay-account">
                    <SelectValue placeholder="Select cash account" />
                  </SelectTrigger>
                  <SelectContent>
                    {cashAccounts.length === 0 ? (
                      <SelectItem value="__none" disabled>No cash accounts found</SelectItem>
                    ) : cashAccounts.map((a) => (
                      <SelectItem key={a.id} value={String(a.id)}>{a.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Worker breakdown */}
              <div className="border rounded-md overflow-hidden max-h-56 overflow-y-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-xs">Worker</TableHead>
                      <TableHead className="text-right text-xs">Base</TableHead>
                      <TableHead className="text-right text-xs">Deduction</TableHead>
                      <TableHead className="text-right text-xs">Net Pay</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {(payDialogRun.items || []).map((it, idx) => (
                      <TableRow key={idx}>
                        <TableCell className="text-sm py-2">{it.employeeName}</TableCell>
                        <TableCell className="text-right text-sm py-2">{formatAmount(parseFloat(it.baseSalary))}</TableCell>
                        <TableCell className="text-right text-sm py-2 text-amber-600 dark:text-amber-400">
                          {parseFloat(it.deduction) > 0 ? `-${formatAmount(parseFloat(it.deduction))}` : "—"}
                        </TableCell>
                        <TableCell className="text-right text-sm py-2 font-semibold">{formatAmount(parseFloat(it.netPay))}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          )}

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setPayDialogRun(null)} data-testid="button-cancel-pay">Cancel</Button>
            <Button
              onClick={() => payDialogRun && payRunMutation.mutate({ runId: payDialogRun.id, accountId: payAccountId })}
              disabled={payRunMutation.isPending || !payAccountId}
              data-testid="button-confirm-pay"
            >
              {payRunMutation.isPending ? (
                <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Processing...</>
              ) : (
                <><DollarSign className="h-4 w-4 mr-2" />Confirm Payment</>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── Delete Confirmation ─────────────────────────────────────────────── */}
      <AlertDialog open={!!deleteRunId} onOpenChange={(open) => { if (!open) setDeleteRunId(null); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Draft?</AlertDialogTitle>
            <AlertDialogDescription>This draft payroll run will be permanently deleted. No ledger entries were created for it.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteRunId && deleteRunMutation.mutate(deleteRunId)}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              data-testid="button-confirm-delete"
            >
              {deleteRunMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
